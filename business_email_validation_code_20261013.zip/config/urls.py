from django.contrib import admin
from django.urls import path
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView
from validator.views import EmailValidateView, health

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/v1/email/validate/", EmailValidateView.as_view(), name="email-validate"),
    path("api/v1/health/", health, name="health"),
    path("api/schema/", SpectacularAPIView.as_view(), name="schema"),
    path("api/docs/", SpectacularSwaggerView.as_view(url_name="schema"), name="swagger-ui"),
]
